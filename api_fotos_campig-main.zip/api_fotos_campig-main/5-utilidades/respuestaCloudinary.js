export class RespuestaCloudinary {
    constructor(url,public_id,formato){
        this.url=url;
        this.public_id=public_id;
        this.formato=formato;
    }
}